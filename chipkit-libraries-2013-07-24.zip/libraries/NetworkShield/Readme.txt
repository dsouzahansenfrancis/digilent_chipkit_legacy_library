NetworkShield Network Hardware Library

1.  To install this library refer to the instructions at ...\libraries\DNETcK\Readme.txt
2.  By default, the NetworkShield works with the following configurations.

        Max32 with Network Shield
        MX7ck and the on board NIC 	
        32MX7 and the on board NIC 	

3.  Include in your sketch NetworkShield.h before you include DNETcK.h. This network hardware library will not work with WiFi.
4.  Then build and run DNETcK as documented in ..\libraries\DNETcK\documents\DNETcK.pdf
5.  Also refer to the NetworkShield example sketches under ...\libraries\DNETcK\examples