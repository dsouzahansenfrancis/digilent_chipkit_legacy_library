How to install the DNETcK/DWIFIcK libraries:

To install this library refer to the instructions at ...\libraries\DNETcK\Readme.txt
