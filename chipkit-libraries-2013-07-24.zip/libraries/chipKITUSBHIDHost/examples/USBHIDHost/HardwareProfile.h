// HardwareProfile.h

#ifndef _HARDWARE_PROFILE_H_
#define _HARDWARE_PROFILE_H_

    #include <p32xxxx.h>
    #include <plib.h>

#endif
