This is the WinUSB driver installables/redistributables 
provided in the Windows Driver Kit (WDK) version 7.0.0 (7600.16385.0).

This version of the WinUSB driver is known as "WinUSB v2".  This
version is newer than the original version provided in the WDK 
version 6001.18001 and 6001.18002.  This newer version is believed to fix
bugs in the original version.

Microsoft may update the WinUSB driver in the future.  If so, any new 
WinUSB driver versions provided by Microsoft are likely to be distributed 
in the WDK (Windows Driver Kit) connection at: connect.microsoft.com 
(which is currently free but requires a login).