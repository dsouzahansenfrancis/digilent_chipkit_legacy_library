PmodNIC Network Hardware Library

1.  To install this library refer to the instructions at ...\libraries\DNETcK\Readme.txt
2.  By default, the PmodNIC100 works with the following configurations.

        Uno32 with PmodShield and PmodNIC on connector JC
        Max32 with PmodShield and PmodNIC on connector JC
        MX3cK with PmodNIC on connector JE				
        MX4ck with PmodNIC on connector JB 				
        32MX4 with PmodNIC on connector JB 				
        MX7ck with PmodNIC on connector JF 				
        32MX7 with PmodNIC on connector JF 				

3.  Include in your sketch PmodNIC.h before you include DNETcK.h. This network hardware library will not work with WiFi.
4.  Then build and run DNETcK as documented in ..\libraries\DNETcK\documents\DNETcK.pdf
5.  Also refer to the PmodNIC example sketches under ...\libraries\DNETcK\examples